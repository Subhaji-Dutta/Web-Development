# Monster Eléctrico

A Pen created on CodePen.io. Original URL: [https://codepen.io/brusespinal/pen/VwdjRxY](https://codepen.io/brusespinal/pen/VwdjRxY).

